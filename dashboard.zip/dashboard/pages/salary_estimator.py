import streamlit as st

def render(engine):
    st.title("Salary Estimator")
    st.write("Coming soon.")